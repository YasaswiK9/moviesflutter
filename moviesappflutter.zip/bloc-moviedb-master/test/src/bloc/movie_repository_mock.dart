import 'package:flutter_bloc_base/src/data/movie_repository.dart';
import 'package:mockito/mockito.dart';

class MovieRepositoryMock extends Mock implements MovieRepository {}
