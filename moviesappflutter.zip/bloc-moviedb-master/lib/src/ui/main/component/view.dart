export 'category_view.dart';
export 'slider_view.dart';
export 'my_list_view.dart';
export 'popular_view.dart';