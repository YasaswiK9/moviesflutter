class Constant {
  static String popular = "popular";
  static String nowPlaying = "now_playing";
  static String topRated = "top_rated";
  static String upcoming = "upcoming";
}