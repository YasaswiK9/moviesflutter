abstract class PrefHelper {
  Future<bool> firstRun();
}