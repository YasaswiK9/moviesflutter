package com.bach.flutter_bloc_base

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
